
import java.util.Arrays;
import java.util.Scanner;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int max = 0, count = 0, index = 0;
		Scanner scan = new Scanner(System.in);
		int i, j;

		System.out.println("Enter the array size:");
		int size = scan.nextInt();
		int arr[] = new int[size];

		int b[] = new int[size];

		System.out.println("Enter the array elements");
		for (i = 0; i < size; i++) {
			arr[i] = scan.nextInt();
		}
		for (i = 0; i < size; i++) {
			count = 0;
			for (j = 0; j < size; j++) {
				if (arr[i] == arr[j]) {
					count++;
				}
			}
			b[i] = count;
			System.out.print(b[i] + " ");
			if (count > max) {
				max = count;
				index = i;
			}

		}
		System.out.println("The maximum occurred element in the array is " + arr[index] + " and the count is " + max);
		Array ex1 = new Array();
		ex1.sortCount(b, arr, size);

		// System.out.println(b);
	}

	static void reverse(int a[], int n) {
		int[] b = new int[n];
		int j = n;
		for (int i = 0; i < n; i++) {
			b[j - 1] = a[i];
			j = j - 1;
		}

//		/* printing the reversed array */
//		System.out.println("Reversed array is: \n");
//		for (int k = 0; k < n; k++) {
//			System.out.print(b[k] + " ");
//		}

		// System.out.println();
	}

	void sortCount(int[] b, int[] arr, int size) {
		// Arrays.sort(b);
		// reverse(b, b.length);
//		for(int i=0;i<b.length;i++) {
//			System.out.print(b[i]);
//		}
		int j, k, temp, swap;
		for (j = 0; j < size; j++) {
			for (k = j + 1; k < size; k++) {
				if (b[j] > b[k]) {
					temp = b[j];
					b[j] = b[k];
					b[k] = temp;
					swap = arr[j];
					arr[j] = arr[k];
					arr[k] = swap;
				}
			}
		}
		// TODO Auto-generated method stub
		for (int i = 0; i < size; i++) {
			System.out.print(arr[i] + " ");
		}
		// input 1 2 5 3 6 1 2 7 8 9 8 1 3 6 7 8 3 5 7 8 2 3 5

	}
}
