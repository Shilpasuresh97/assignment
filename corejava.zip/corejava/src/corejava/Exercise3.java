package corejava;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scan=new Scanner(System.in);
		 Map<String,Integer> map=new HashMap<String,Integer>();  
		 map.put("Chennai � Trichy" , 300);
		 map.put("Chennai � Madurai" ,500);
		 map.put("Trichy � Madurai" , 200);
		 map.put("Madurai � Rameshwaram" , 160);
		 map.put("Rameshwaram � Trichy" , 230);
		 map.put("Rameshwaram � Chennai" , 550);
		 int total=0;
		 Map<String,Integer> map1=new HashMap<String,Integer>();
		 int size=scan.nextInt();
		 
		 for(int i=0;i<size;i++) {
			 
			 String key=scan.next();
			 int value=scan.nextInt();
			 map1.put(key, value);
			 if(map.get(key).equals(map1.get(key))) {
			
				//total=map.values();
			 }
	         
		 
	}
		// System.out.println(map.put(key, value));

}}

