package corejava;

public class Exercise4 {

}
