
import java.util.HashMap;
import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class Creditcard {

	public static void main(String args[]) {
		Map<Integer, String> map = new HashMap<Integer, String>();
		map.put(100, "Platinum");
		map.put(60, "Gold");
		map.put(90, "Platinum");
		map.put(20, "Silver");
		map.put(10, "Gold");
		map.put(80, "Platinum");
		int maxScore = 0;
		String card = "";

		String Priority1 = "Platinum";
		String Priority2 = "Gold";
		String Priority3 = "Silver";
		for (Map.Entry<Integer, String> entry : map.entrySet()) {
			if (entry.getValue().equals(Priority1)) {
				if (entry.getKey() > maxScore) {
					maxScore = entry.getKey();
					card = entry.getValue();
				}

			} else if (entry.getValue().equals(Priority2)) {
				if (map.containsValue("Platinum")) {
					maxScore = maxScore;
				} else {
					if (entry.getKey() > maxScore) {
						maxScore = entry.getKey();
						card = entry.getValue();
					}

				}
			} else if (entry.getValue().equals(Priority3)) {
				if (map.containsValue("Platinum")) {
					maxScore = maxScore;
					// card=entry.getValue();
				} else if (map.containsValue("Gold")) {
					maxScore = maxScore;
					// card=entry.getValue();
				} else {
					if (entry.getKey() > maxScore) {
						maxScore = entry.getKey();
						card = entry.getValue();
					}

				}
			}
		}

		System.out.println("The best card is " + card + " and its score is " + maxScore);
	}

}
