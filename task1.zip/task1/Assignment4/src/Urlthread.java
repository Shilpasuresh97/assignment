
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Urlthread {

	public static void main(String[] args) throws Exception {
		ExecutorService executor = Executors.newFixedThreadPool(2);
		String urlList[] = {
				"http://data.fixer.io/api/latest?access_key=901564ff47fd77d82fdb7cc677e6c55b&symbols=USD,&format=1",
				"http://data.fixer.io/api/latest?access_key=901564ff47fd77d82fdb7cc677e6c55b&symbols=USD,&format=1" };

		for (int i = 0; i < urlList.length; i++) {
			String url = urlList[i];
			Runnable worker = new MyRunnable(url);
			executor.execute(worker);
		}
		executor.shutdown();

	}
}

class MyRunnable implements Runnable {

	private final String url;

	MyRunnable(String url) {
		this.url = url;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
//		String result="";
		URL url1 = null;
		URLConnection urlConn = null;
		InputStreamReader in = null;
		StringBuilder sb = new StringBuilder();
		try {
			url1 = new URL(url);
		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			urlConn = url1.openConnection();
		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			if (urlConn != null && urlConn.getInputStream() != null) {
				in = new InputStreamReader(urlConn.getInputStream());
				BufferedReader bufferedReader = new BufferedReader(in);
				if (bufferedReader != null) {
					String str;
					while ((str = bufferedReader.readLine()) != null) {
						sb.append(str);
					}
					bufferedReader.close();

				}
			}
			in.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(sb.toString());

	}

}