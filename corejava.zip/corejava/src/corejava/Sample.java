package corejava;
import java.awt.List;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;
import java.util.Set;
 
public class Sample
{   
    static void getMostFrequentElement(int inputArray[])
    {   
        HashMap<Integer, Integer> elementCountMap = new HashMap<Integer, Integer>();
         
        for (int i : inputArray) 
        {
            if (elementCountMap.containsKey(i))
            {
                
                 
                elementCountMap.put(i, elementCountMap.get(i)+1);
            }
            else
            {
                
                 
                elementCountMap.put(i, 1);
            }
        }
         
        int element = 0;
         
        int frequency = 1;
         
       
         
        Set<Entry<Integer, Integer>> entrySet = elementCountMap.entrySet();
        System.out.println("entryset:"+entrySet);
         
        for (Entry<Integer, Integer> entry : entrySet) 
        {
            if(entry.getValue() > frequency)
            {
                element = entry.getKey();
                 
                frequency = entry.getValue();
            }
            //System.out.println("element:"+element);
           // System.out.println("freq:"+frequency);
        }
       
         
         
        if(frequency > 1)
        {
            System.out.println("Input Array : "+Arrays.toString(inputArray));
             
            System.out.println("The most frequent element : "+element);
             
            System.out.println("Its frequency : "+frequency);
             
        }
        else
        {
            System.out.println("Input Array : "+Arrays.toString(inputArray));
             
            System.out.println("No frequent element. All elements are unique.");
             
            
        }
       
    }
      
     
  

	public static void main(String[] args)
    {
    	Scanner scan=new Scanner(System.in);
		int size=scan.nextInt();
		int arr[]=new int[size];
		for(int i=0;i<size;i++) {
			arr[i]=scan.nextInt();
         
		}
		 getMostFrequentElement(arr);
    }
}

