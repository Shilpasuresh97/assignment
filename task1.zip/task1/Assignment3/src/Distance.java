import java.util.Scanner;

public class Distance {
	public static void main(String[] args) {
		int total = 0;
		int total1 = 0;
		int number;
		Scanner scan = new Scanner(System.in);
		do {

			System.out.println("enter the source:");
			String source = scan.next();
			System.out.println("Enter the destination:");
			String destination = scan.next();
			if ((source.equals("Chennai") && destination.equals("Trichy"))
					|| (source.equals("Trichy") && destination.equals("Chennai"))) {
				total = total + 300;
			} else if ((source.equals("Chennai") && destination.equals("Madurai"))
					|| (source.equals("Madurai") && destination.equals("Chennai"))) {
				total = total + 500;
			} else if ((source.equals("Trichy") && destination.equals("Madurai"))
					|| (source.equals("Madurai") && destination.equals("Trichy"))) {
				total = total + 200;
			} else if ((source.equals("Madurai") && destination.equals("Rameshwaram"))
					|| (source.equals("Rameshwaram") && destination.equals("Madurai"))) {
				total = total + 160;
			} else if ((source.equals("Rameshwaram") && destination.equals("Trichy"))
					|| (source.equals("Trichy") && destination.equals("Rameshwaram"))) {
				total = total + 230;
			} else if ((source.equals("Rameshwaram") && destination.equals("Chennai"))
					|| (source.equals("Chennai") && destination.equals("Rameshwaram"))) {
				total = total + 550;
			}

			total1 = total;
			System.out.println("enter 1 if journey continues else enter 0");
			number = scan.nextInt();

		} while (number != 0);
		System.out.println("The total distance covered by the traveller: " + total1);
	}
}
